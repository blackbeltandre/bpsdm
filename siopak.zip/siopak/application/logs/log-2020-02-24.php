<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-24 06:20:22 --> Query error: Unknown column 'id_tipefungsional' in 'field list' - Invalid query: INSERT INTO `karyawan` (`nip`, `nik`, `nama_lengkap`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `email`, `no_telp`, `id_golongan`, `id_tipefungsional`, `id_jenjang`) VALUES ('123123123', '321321321', 'Maulana qi', 'Jakarta', '2020-12-30', 'adad                                ', 'ada@gmail.com', '087887142364', '1', '1', '1')
ERROR - 2020-02-24 09:56:58 --> Query error: Cannot truncate a table referenced in a foreign key constraint (`payunganakbangsa_siopak`.`penilaian_file`, CONSTRAINT `penilaian_file_ibfk_1` FOREIGN KEY (`id_penilaian`) REFERENCES `payunganakbangsa_siopak`.`penilaian` (`id_penilaian`)) - Invalid query: TRUNCATE `penilaian`
ERROR - 2020-02-24 10:02:35 --> Query error: Unknown column 'token' in 'field list' - Invalid query: INSERT INTO `users` (`nip`, `password`, `is_dupak`, `aktif`, `token`) VALUES ('123123123', 'f5bb0c8de146c67b44babbf4e6584cc0', 1, 0, 'e085e96885050eacdde84276a261286b')
ERROR - 2020-02-24 14:52:24 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `penguji` (`nip`, `tahun`, `created_by`, `created_date`) VALUES ('1113093000082', '2020', NULL, '2020-02-24 14:52:24')
ERROR - 2020-02-24 14:53:17 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `penguji` (`nip`, `tahun`, `created_by`, `created_date`) VALUES ('1113093000082', '2020', NULL, '2020-02-24 14:53:17')
ERROR - 2020-02-24 15:17:17 --> Query error: Column 'golongan' cannot be null - Invalid query: INSERT INTO `penilaian` (`tanggal_pengajuan`, `nip`, `tahun`, `created_by`, `created_date`, `status`, `golongan`) VALUES ('2020-02-24', 'admin', '2020', 'Administrator', '2020-02-24 15:17:17', 1, NULL)
ERROR - 2020-02-24 15:37:17 --> Query error: Unknown column 'id_status' in 'field list' - Invalid query: UPDATE `penilaian` SET `id_status` = 4
WHERE `nip` = '1113093000080'
AND `tahun` = '2020'
ERROR - 2020-02-24 15:38:05 --> Query error: Unknown column 'id_status' in 'field list' - Invalid query: UPDATE `penilaian` SET `id_status` = 4
WHERE `nip` = '1113093000082'
AND `tahun` = '2020'
ERROR - 2020-02-24 15:41:43 --> Query error: Unknown column 'id_status' in 'field list' - Invalid query: UPDATE `penilaian` SET `id_status` = 4
WHERE `nip` = '197403022001121001'
AND `tahun` = '2020'
ERROR - 2020-02-24 15:42:09 --> Query error: Unknown column 'id_status' in 'field list' - Invalid query: UPDATE `penilaian` SET `id_status` = 4
WHERE `nip` = '197403022001121001'
AND `tahun` = '2020'
