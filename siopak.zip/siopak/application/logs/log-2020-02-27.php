<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-27 11:06:29 --> Severity: Parsing Error --> syntax error, unexpected '$CI' (T_VARIABLE), expecting ')' /home/payunganakbangsa/public_html/siopak/application/helpers/web_helper.php 398
ERROR - 2020-02-27 11:06:30 --> Severity: Parsing Error --> syntax error, unexpected '$CI' (T_VARIABLE), expecting ')' /home/payunganakbangsa/public_html/siopak/application/helpers/web_helper.php 398
ERROR - 2020-02-27 11:06:31 --> Severity: Parsing Error --> syntax error, unexpected '$CI' (T_VARIABLE), expecting ')' /home/payunganakbangsa/public_html/siopak/application/helpers/web_helper.php 398
