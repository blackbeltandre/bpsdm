<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-28 02:29:07 --> Severity: Error --> Call to undefined function back_button() /home/payunganakbangsa/public_html/siopak/application/views/admin/pages/user/add_user.php 2
ERROR - 2020-02-28 02:29:11 --> Severity: Error --> Call to undefined function back_button() /home/payunganakbangsa/public_html/siopak/application/views/admin/pages/user/add_user.php 2
ERROR - 2020-02-28 02:29:11 --> Severity: Error --> Call to undefined function back_button() /home/payunganakbangsa/public_html/siopak/application/views/admin/pages/user/add_user.php 2
ERROR - 2020-02-28 03:26:50 --> Severity: Error --> Call to undefined function get_pejabat() /home/payunganakbangsa/public_html/siopak/application/controllers/penguji/Pengujian.php 29
ERROR - 2020-02-28 03:27:42 --> Severity: Error --> Call to undefined function get_pejabat() /home/payunganakbangsa/public_html/siopak/application/controllers/penguji/Pengujian.php 29
ERROR - 2020-02-28 03:27:45 --> Severity: Error --> Call to undefined function get_pejabat() /home/payunganakbangsa/public_html/siopak/application/controllers/penguji/Pengujian.php 29
ERROR - 2020-02-28 03:28:25 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `penguji_jabfung` (`nip_jabfung`, `nip_penguji`, `tahun`, `created_by`, `created_date`) VALUES ('1113093000084', '1113093000080', '2020', NULL, '2020-02-28 03:28:25')
ERROR - 2020-02-28 03:29:12 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `penguji` (`nip`, `tahun`, `created_by`, `created_date`) VALUES ('1113093000087', '2020', NULL, '2020-02-28 03:29:12')
ERROR - 2020-02-28 04:01:17 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `penguji` (`nip`, `tahun`, `created_by`, `created_date`) VALUES ('123123123', '2020', NULL, '2020-02-28 04:01:17')
ERROR - 2020-02-28 04:01:17 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `penguji` (`nip`, `tahun`, `created_by`, `created_date`) VALUES ('198203102008121001', '2020', NULL, '2020-02-28 04:01:17')
ERROR - 2020-02-28 04:02:46 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `penguji` (`nip`, `tahun`, `created_by`, `created_date`) VALUES ('123123123123123123', '2020', NULL, '2020-02-28 04:02:46')
ERROR - 2020-02-28 04:47:05 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `penguji` (`nip`, `tahun`, `created_by`, `created_date`) VALUES ('1113093000087', '2020', NULL, '2020-02-28 04:47:05')
ERROR - 2020-02-28 04:48:01 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `penguji` (`nip`, `tahun`, `created_by`, `created_date`) VALUES ('1113093000082', '2020', NULL, '2020-02-28 04:48:01')
ERROR - 2020-02-28 06:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 92
ERROR - 2020-02-28 06:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 110
ERROR - 2020-02-28 06:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 143
ERROR - 2020-02-28 06:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 186
ERROR - 2020-02-28 06:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 209
ERROR - 2020-02-28 06:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 92
ERROR - 2020-02-28 06:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 110
ERROR - 2020-02-28 06:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 143
ERROR - 2020-02-28 06:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 186
ERROR - 2020-02-28 06:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 209
