<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-03 00:28:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 292
ERROR - 2020-03-03 00:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 292
