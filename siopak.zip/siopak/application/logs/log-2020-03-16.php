<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-16 02:24:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 292
ERROR - 2020-03-16 02:33:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 292
ERROR - 2020-03-16 02:39:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 292
ERROR - 2020-03-16 02:41:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 292
ERROR - 2020-03-16 02:59:27 --> Severity: Warning --> Missing argument 1 for Penguji::tambahjabfung() /home/payunganakbangsa/public_html/siopak/application/controllers/backend/Penguji.php 169
ERROR - 2020-03-16 03:32:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 292
ERROR - 2020-03-16 03:47:46 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '38'
ERROR - 2020-03-16 03:50:09 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '38'
ERROR - 2020-03-16 03:51:15 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '38'
ERROR - 2020-03-16 06:23:21 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: UPDATE `karyawan` SET `nip` = '197403022001121051', `nik` = '3175050203740059', `nama_lengkap` = 'Septian Carito, S.kom,MMsi.', `tempat_lahir` = 'Jakarta', `tanggal_lahir` = '1992-03-09', `alamat` = 'Jl.Tipar Cakung RT 10 RW 007  Cakung Barat, Cakung, Jakarta Timur.', `email` = 'caritoseptian@gmail.com', `no_telp` = '085893410023', `id_golongan` = '4'
WHERE `id_karyawan` = '38'
ERROR - 2020-03-16 06:24:22 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: UPDATE `karyawan` SET `nip` = '197403022001121051', `nik` = '3175050203740059', `nama_lengkap` = 'Septian Carito, S.kom,MMsi.', `tempat_lahir` = 'Jakarta', `tanggal_lahir` = '1992-03-09', `alamat` = 'Jl.Tipar Cakung RT 10 RW 007  Cakung Barat, Cakung, Jakarta Timur.', `email` = 'caritoseptian@gmail.com', `no_telp` = '085893410023', `id_golongan` = '4'
WHERE `id_karyawan` = '38'
ERROR - 2020-03-16 06:25:15 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '38'
ERROR - 2020-03-16 07:26:47 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '38'
