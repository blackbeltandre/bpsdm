<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-23 02:51:56 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '28'
ERROR - 2020-03-23 02:52:15 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '28'
ERROR - 2020-03-23 02:52:31 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '28'
ERROR - 2020-03-23 02:53:23 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '28'
ERROR - 2020-03-23 02:54:20 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '28'
ERROR - 2020-03-23 02:56:52 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '28'
ERROR - 2020-03-23 03:32:04 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`payunganakbangsa_siopak`.`dupak`, CONSTRAINT `fk_nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`)) - Invalid query: DELETE FROM `karyawan`
WHERE `id_karyawan` = '28'
