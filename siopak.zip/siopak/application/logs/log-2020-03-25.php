<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-25 04:23:48 --> Severity: Warning --> Missing argument 1 for Penguji::tambahjabfung() /home/payunganakbangsa/public_html/siopak/application/controllers/backend/Penguji.php 169
ERROR - 2020-03-25 04:36:32 --> Severity: Warning --> Missing argument 1 for Penguji::tambahjabfung() /home/payunganakbangsa/public_html/siopak/application/controllers/backend/Penguji.php 169
ERROR - 2020-03-25 04:37:11 --> Severity: Warning --> Missing argument 1 for Penguji::tambahjabfung() /home/payunganakbangsa/public_html/siopak/application/controllers/backend/Penguji.php 169
ERROR - 2020-03-25 04:42:33 --> Severity: Warning --> Missing argument 1 for Penguji::tambahjabfung() /home/payunganakbangsa/public_html/siopak/application/controllers/backend/Penguji.php 169
ERROR - 2020-03-25 04:48:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/payunganakbangsa/public_html/siopak/application/controllers/Repassword.php:54) /home/payunganakbangsa/public_html/siopak/system/helpers/url_helper.php 564
ERROR - 2020-03-25 05:04:37 --> Severity: Warning --> Missing argument 1 for Pengajuan::detail() /home/payunganakbangsa/public_html/siopak/application/controllers/backend/Pengajuan.php 63
ERROR - 2020-03-25 05:11:27 --> Severity: Warning --> Missing argument 1 for Pengajuan::detail() /home/payunganakbangsa/public_html/siopak/application/controllers/backend/Pengajuan.php 63
ERROR - 2020-03-25 05:21:25 --> Severity: Warning --> Missing argument 1 for Pengajuan::detail() /home/payunganakbangsa/public_html/siopak/application/controllers/backend/Pengajuan.php 63
ERROR - 2020-03-25 07:34:54 --> The upload path does not appear to be valid.
ERROR - 2020-03-25 07:38:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 119
ERROR - 2020-03-25 07:38:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 137
ERROR - 2020-03-25 07:38:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 170
ERROR - 2020-03-25 07:38:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 214
ERROR - 2020-03-25 07:38:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 237
ERROR - 2020-03-25 07:38:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 292
ERROR - 2020-03-25 07:39:14 --> The upload path does not appear to be valid.
ERROR - 2020-03-25 07:59:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 119
ERROR - 2020-03-25 07:59:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 137
ERROR - 2020-03-25 07:59:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 170
ERROR - 2020-03-25 07:59:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 214
ERROR - 2020-03-25 07:59:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 237
ERROR - 2020-03-25 07:59:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 292
ERROR - 2020-03-25 09:06:49 --> Severity: Warning --> Missing argument 1 for Penguji::tambahjabfung() /home/payunganakbangsa/public_html/siopak/application/controllers/backend/Penguji.php 169
ERROR - 2020-03-25 09:07:00 --> Severity: Warning --> Missing argument 1 for Penguji::hapus() /home/payunganakbangsa/public_html/siopak/application/controllers/backend/Penguji.php 153
ERROR - 2020-03-25 09:07:02 --> Severity: Warning --> Missing argument 1 for Penguji::hapus() /home/payunganakbangsa/public_html/siopak/application/controllers/backend/Penguji.php 153
ERROR - 2020-03-25 09:11:58 --> The upload path does not appear to be valid.
ERROR - 2020-03-25 09:12:10 --> The upload path does not appear to be valid.
ERROR - 2020-03-25 09:23:31 --> Query error: Table 'payunganakbangsa_siopak.ref_kelulusan' doesn't exist - Invalid query: SELECT *
FROM `ref_kelulusan`
WHERE `id_golongan` = '1'
ERROR - 2020-03-25 09:23:31 --> Severity: Error --> Call to a member function row() on boolean /home/payunganakbangsa/public_html/siopak/application/controllers/penguji/Pengujian.php 139
ERROR - 2020-03-25 09:23:38 --> Query error: Table 'payunganakbangsa_siopak.ref_kelulusan' doesn't exist - Invalid query: SELECT *
FROM `ref_kelulusan`
WHERE `id_golongan` = '1'
ERROR - 2020-03-25 09:23:38 --> Severity: Error --> Call to a member function row() on boolean /home/payunganakbangsa/public_html/siopak/application/controllers/penguji/Pengujian.php 139
