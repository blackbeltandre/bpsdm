<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-20 00:34:54 --> Query error: Column 'nip' cannot be null - Invalid query: INSERT INTO `penilaian` (`tanggal_pengajuan`, `nip`, `tahun`, `ak_lama0`, `created_by`, `created_date`, `status`, `golongan`) VALUES ('2020-04-20', NULL, '2020', NULL, NULL, '2020-04-20 00:34:54', 1, NULL)
ERROR - 2020-04-20 00:35:05 --> Query error: Column 'nip' cannot be null - Invalid query: INSERT INTO `penilaian` (`tanggal_pengajuan`, `nip`, `tahun`, `ak_lama0`, `created_by`, `created_date`, `status`, `golongan`) VALUES ('2020-04-20', NULL, '2020', NULL, NULL, '2020-04-20 00:35:05', 1, NULL)
ERROR - 2020-04-20 05:30:19 --> Query error: Table 'payunganakbangsa_siopak.ref_kelulusan' doesn't exist - Invalid query: SELECT *
FROM `ref_kelulusan`
WHERE `id_golongan` = '1'
ERROR - 2020-04-20 05:30:19 --> Severity: Error --> Call to a member function row() on boolean /home/payunganakbangsa/public_html/siopak/application/controllers/penguji/Pengujian.php 169
ERROR - 2020-04-20 05:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/libraries/Hitungdupak.php 159
ERROR - 2020-04-20 05:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/libraries/Hitungdupak.php 209
ERROR - 2020-04-20 05:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/libraries/Hitungdupak.php 111
ERROR - 2020-04-20 05:46:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/libraries/Hitungdupak.php 282
