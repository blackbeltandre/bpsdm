<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-31 14:13:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 295
ERROR - 2020-05-31 14:13:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/payunganakbangsa/public_html/siopak/application/views/pages/biodata/index.php 295
