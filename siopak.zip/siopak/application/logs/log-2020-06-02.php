<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-02 04:36:53 --> Query error: Table 'payunganakbangsa_siopak.ref_kelulusan' doesn't exist - Invalid query: SELECT *
FROM `ref_kelulusan`
WHERE `id_golongan` = '4'
ERROR - 2020-06-02 04:36:53 --> Severity: Error --> Call to a member function row() on boolean /home/payunganakbangsa/public_html/siopak/application/controllers/penguji/Pengujian.php 169
